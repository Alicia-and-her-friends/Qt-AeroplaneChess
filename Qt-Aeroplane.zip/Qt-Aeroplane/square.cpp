#include "square.h"

square::square(){}
