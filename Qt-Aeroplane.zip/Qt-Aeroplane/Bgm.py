import pygame

# 初始化Pygame
pygame.init()

# 加载背景音乐文件
pygame.mixer.music.load("/Users/vincentarak/QTs/Sources/Bgm.mp3")
bgm_file="/Users/vincentarak/QTs/Sources/Bgm.mp3"
# 设置音量
pygame.mixer.music.set_volume(0.5)

# 循环播放背景音乐
pygame.mixer.music.play(-1)

#while True:
    # 加载音乐文件
#    pygame.mixer.music.load(bgm_file)

    # 播放音乐
#    pygame.mixer.music.play()

    # 等待音乐播放完成
#    pygame.mixer.music.wait()

# 退出pygame
pygame.quit()



path="/Users/vincentarak/QTs/Sources/bgm.mp3"
