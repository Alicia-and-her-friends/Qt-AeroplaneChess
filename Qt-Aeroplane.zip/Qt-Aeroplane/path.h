#ifndef PATH_H
#define PATH_H

#include <cstring>
#include <iostream>
namespace Upath{
    const std::string file_path_="/Users/vincentarak/QTs/Sources";
};

#endif // PATH_H
